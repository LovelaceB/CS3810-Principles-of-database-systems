/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw6;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


/**
 * This is a program that takes user information and inserts it into a 
 * Pgsql database, from which the user can view and schedule flights.
 * @author Benjewman
 */
public class HW6 {

    static String NameFirst, NameLast, Address, City, State, Zip, Phone, mail;
    static int flightNumber = 0;
    static Scanner scn = new Scanner(System.in);
    static Connection conn = null;
    static ResultSet rs = null;
    static Statement ps = null;
    static int date = 1234;
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        //openConnection();
        getInfo();
        //createTable();
        insertCustomerData();
        chooseFlight();
        printTicket();
        //conn.close(); //just in case
    }

    public static void openConnection() {
        try {
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres",
                    "postgres", "postgres");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        System.out.println("Opened database successfully");
    }

    public static void getInfo() throws IOException {
        FileWriter fileWriter = new FileWriter("HW6.error");
        PrintWriter printWriter = new PrintWriter(fileWriter);
        System.out.println("Enter your First Name");
        NameFirst = scn.nextLine();
        System.out.println("Enter your Last Name");
        NameLast = scn.nextLine();
        System.out.println("Enter your email address.");
        mail = scn.nextLine();
        if (!(mail.contains("@"))) {
            System.out.println("Sorry, you have entered an invalid email address.");
            printWriter.print("Customer " + NameLast + ", " + NameFirst + " entered an invalid email " + mail);
            printWriter.close();
            System.exit(0);
        }

        System.out.println("Enter your Phone number");
        Phone = scn.nextLine();
        if (Phone.length() != 10) {
            System.out.println("Please enter a valid phone number ");

            printWriter.println(NameFirst+NameLast+"Entered a phone number in the wrong format " + Phone);
            printWriter.close();
            System.exit(0);
        }

        System.out.println("Enter your Adress without the Zip code State or City");
        Address = scn.nextLine();
        System.out.println("Enter City you live in:");
        City = scn.nextLine();
        System.out.println("Enter your State ");
        State = scn.nextLine();

        System.out.println("Enter your ZIP code");
        Zip = scn.nextLine();
        if (Zip.length() != 5) {
            System.out.println("Enter a zip code with 5 digits next time");
            printWriter.println("Wrong Zip format " + Zip);
            printWriter.close();
            System.exit(0);
        }

    }

    private static void insertCustomerData() {
        try {
            openConnection();
            conn.setAutoCommit(false);
            ps = conn.createStatement();

            String insertCustomer = "INSERT INTO Customer (First_name, Last_name, Address, City, State, Zip,Phone, Email)"
                    + "VALUES ('" + NameFirst + "', '" + NameLast + "','" + Address + "', '" + City + "', '" + State + "', '" + Zip + "', '" + Phone + "' ,'" + mail + "')";
            ps.executeUpdate(insertCustomer);
            ps.close();
            conn.commit();
            conn.close();
        } catch (SQLException e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
    }
    private static void chooseFlight() {
        System.out.print("From what city would your flight originate?: ");
        String origin = scn.nextLine();
        try {
            openConnection();
            conn.setAutoCommit(false);
            ps = conn.createStatement();
            rs = ps.executeQuery("SELECT * FROM Flight WHERE (Origin_City_Name = '"+origin+"');");
            if (!rs.isBeforeFirst()) {
                System.out.println("Sorry, that's not a valid origin city, please restart program.");
                System.exit(0);
            } else {
                System.out.println("Here is a list of flights that originate in selected city:  " + origin);
                System.out.println("-------------------------------------------------------------");
            }
            while (rs.next()) {
                String airline = rs.getString("Airline_Code");
                int flightNumber = rs.getInt("Flight_Num");
                String originCity = rs.getString("Origin_City_Name");
                String destination = rs.getString("Dest_City_Name");
                System.out.println(airline + " flight " + flightNumber + " flies from " + originCity + " to " +
                        destination);
            }
            rs.close();
            ps.close();
            conn.close();
        } catch (SQLException e) {
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            System.exit(0);
        }
        int counter = 0;
        do {
            System.out.print("Choose a destination city from the above list of flights: ");
            String destCity = scn.nextLine();
            try {
                openConnection();
                conn.setAutoCommit(false);
                ps = conn.createStatement();
                rs = ps.executeQuery("SELECT * FROM Flight WHERE (Origin_City_Name = '" + origin + "' AND Dest_City_Name = '"
                        + destCity + "')");
                if (!rs.isBeforeFirst()) {
                    System.out.println("Sorry, that's not a valid destination. "
                            + "You have 3 total attempts to enter a valid destination ");
                    
                    counter++;
                    System.out.println(counter+ " Attempt(s) used");
                    if (counter == 3) {
                        System.out.println("Maximum Attempts reached");
                        rs.close();
                        ps.close();
                        conn.close();
                        System.exit(0);
                    }
                } else {
                    rs.next();
                    flightNumber = rs.getInt("Flight_Num");
                    break;
                }
            } catch (SQLException e) {
                System.err.println(e.getClass().getName() + ": " + e.getMessage());
                System.exit(0);
            }
        } while (counter < 3);
        try {
            rs.close();
            ps.close();
            conn.close();
        } catch (SQLException e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
    }
    private static void printTicket() throws IOException {
        FileWriter fileWriter = new FileWriter("HW6.flight");
        PrintWriter printWriter = new PrintWriter(fileWriter);

        try {
            openConnection();
            conn.setAutoCommit(false);
            ps = conn.createStatement();
            rs = ps.executeQuery("SELECT * FROM Flight WHERE Flight_Num = "+flightNumber+"");
            rs.next();
            String airline = rs.getString("Airline_Code");
            String origin = rs.getString("Origin_City_Name");
            String destination = rs.getString("Dest_City_Name");
            String departDate = rs.getString("Date_Departure");
            String departTime = rs.getString("Time_Departure");
            String arrivalTime = rs.getString("Time_Arrival");
            String flightLength = rs.getString("Length_Time");
            String bookingNum = rs.getString("Booking_Num");
            printWriter.println("Customer Information");
            printWriter.println("---------------------");
            printWriter.println("Name: "+ NameFirst + " " + NameLast);
            printWriter.println("Address: " + Address + ", " + City + ", " + State + ", " +
                                Zip);
            printWriter.println("Phone: " + Phone);
            printWriter.println("Email: " + mail);
            printWriter.println("Flight Information");
            printWriter.println("--------------------------");
            printWriter.println("Airline: " + airline);
            printWriter.println("Flight number: " + flightNumber);
            printWriter.println("Departing from: " + origin);
            printWriter.println("Destination: " + destination);
            printWriter.println("Date of Departure: " + departDate);
            printWriter.println("Time of Departure: " + departTime);
            printWriter.println("Arrival Time: " + arrivalTime);
            printWriter.println("Length of Flight: " + flightLength);
            String insertReservation = "INSERT INTO Booking (First_Name, Last_Name, Booking_Num, "
                    + "Date_Booking, Origin_City, Dest_City, Flight_Num) VALUES('"+NameFirst+"', '" +NameLast+"', '"
                    +bookingNum+"', '"+date+"', '"+origin+"', '"+destination+"', '"+flightNumber+"')";
            ps.executeUpdate(insertReservation);
            rs.close();
            ps.close();
            printWriter.close();
            conn.commit();
            conn.close();
            System.out.println("Flight Scheduled, here is your ticket with flight information .");
            System.out.println();
            System.out.println("Name: "+ NameFirst + " " + NameLast);
            System.out.println("Address: " + Address + ", " + City + ", " + State + ", " +
                    Zip);
            System.out.println("Phone: " + Phone);
            System.out.println("Email: " + mail);
            System.out.println();
            System.out.println("Flight Information");
            System.out.println("---------------------");
            System.out.println("Airline: " + airline);
            System.out.println("Flight number: " + flightNumber);
            System.out.println("Departing from: " + origin);
            System.out.println("Destination: " + destination);
            System.out.println("Date of Departure: " + departDate);
            System.out.println("Time of Departure: " + departTime);
            System.out.println("Arrival Time: " + arrivalTime);
            System.out.println("Length of Flight: " + flightLength);
            System.out.println();
            System.out.println("Your ticket can also be seen on the HW6.flight file");
        } catch (SQLException e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
    }
}

